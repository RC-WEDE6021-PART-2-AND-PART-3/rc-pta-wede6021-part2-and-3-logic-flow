<?php
include("DBConn.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
$username = $_POST['username'] ??'';
$email = $_POST['email']??'';
$password = $_POST['password']??''; // match given hash format

}
$sql = "SELECT * FROM users 
        WHERE username='$username' AND email='$email'";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $user = $result->fetch_assoc();

    if (!$user['is_verified']) {
        echo "Account pending admin approval.";
        exit;
    }

    if ($password === $user['password_hash']) {
        echo "User $username is logged in";

        echo "<table border='1'>";
        foreach ($user as $key => $value) {
            echo "<tr><td>$key</td><td>$value</td></tr>";
        }
        echo "</table>";

    } else {
        echo "Incorrect password!";
    }

} else {
    echo "User not found. Please register.";
}
?>