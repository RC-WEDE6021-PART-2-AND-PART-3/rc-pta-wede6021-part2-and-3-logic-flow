<!DOCTYPE html>
<html>
<head>
    <title>Clothing Store</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<header>
    <h1>Clothing Store</h1>
    <nav>
        <a href="login.php">Home</a>
        <a href="login.php">Login</a>
        <a href="register.php">Register</a>
        <a href="admin.php">Admin</a>
    </nav>
</header>

<main>
  <div class="card">
        <h2>Login</h2>

        <form method="POST">
            <input type="username" name="username" placeholder="Username">
            <input type="email" name="email" placeholder="Email" required>
            <input type="password" name="password" placeholder="Password" required>

            <button type="submit">Login</button>
        </form>

        <p style="color:red;"><?php echo $message ?? ''; ?></p>
    </div>
</main>

<footer>
    <p>© 2026 Clothing Store</p>
</footer>

</body>
</html>