<?php
include 'DBConn.php';

// Get unverified users
$sql = "SELECT * FROM USERS WHERE is_verified = 0";
$result = $conn->query($sql);

// Error check
if (!$result) {
    die("Query failed: " . $conn->error);
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Clothing Store</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<header>
    <h1>Clothing Store</h1>
    <nav>
        <a href="login.php">Home</a>
        <a href="login.php">Login</a>
        <a href="register.php">Register</a>
        <a href="admin.php">Admin</a>
    </nav>
</header>

<main>
    <div class="card">
        <h2>Pending Users</h2>

        <table>
            <tr>
                <th>Username</th>
                <th>Email</th>
                <th>Action</th>
            </tr>

            <?php if ($result->num_rows > 0): ?>
                <?php while($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?= $row['username'] ?></td>
                    <td><?= $row['email'] ?></td>
                    <td>
                        <a href="verify.php?id=<?= $row['user_id'] ?>">Verify</a>
                    </td>
                </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="3">No pending users</td>
                </tr>
            <?php endif; ?>
        </table>
    </div>
</main>

<footer>
    <p>© 2026 Clothing Store</p>
</footer>

</body>
</html>