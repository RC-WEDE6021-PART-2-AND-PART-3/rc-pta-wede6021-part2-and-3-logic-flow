<!DOCTYPE html>
<html>
<head>
    <title>Clothing Store</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<header>
    <h1>Clothing Store</h1>
    <nav>
        <a href="login.php">Home</a>
        <a href="login.php">Login</a>
        <a href="register.php">Register</a>
        <a href="admin.php">Admin</a>
    </nav>
</header>

<main>
    <div class="card">
        <h2>Register</h2>

        <form method="POST">
            <input type="text" name="username" placeholder="Username" required>
            <input type="email" name="email" placeholder="Email" required>
            <input type="password" name="password" placeholder="Password" required>

            <button type="submit">Register</button>
        </form>
    </div>
</main>

<footer>
    <p>© 2026 Clothing Store</p>
</footer>

</body>
</html>
<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include("DBConn.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $username = $_POST['username'] ?? '';
    $email = $_POST['email'] ?? '';
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $sql = "INSERT INTO users (username, email, password_hash, is_verified)
            VALUES ('$username', '$email', '$password', 0)";

    if ($conn->query($sql) === TRUE) {
        echo "Registered successfully. Await admin approval.";
    } else {
        echo "Error: " . $conn->error;
    }
}
?>