<?php
include("DBConn.php");

// Drop table
$conn->query("DROP TABLE IF EXISTS users");

// Create table
$conn->query("
CREATE TABLE users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100),
    email VARCHAR(100),
    password_hash VARCHAR(255),
    is_verified BOOLEAN DEFAULT 1
)");

// Load data from text file
$file = fopen("userData.txt", "r");

while (($line = fgets($file)) !== false) {
    $data = explode(" ", trim($line));
    
    $username = $data[0] . " " . $data[1];
    $email = $data[2];
    $password = $data[3];

    $conn->query("INSERT INTO users (username, email, password_hash)
                  VALUES ('$username', '$email', '$password')");
}

fclose($file);

echo "Table recreated and data loaded!";
?>