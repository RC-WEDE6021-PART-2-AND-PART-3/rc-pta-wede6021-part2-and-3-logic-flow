<?php
include("DBConn.php");

$sql = file_get_contents("myClothingStore.sql");

if ($conn->multi_query($sql)) {
    echo "Database loaded successfully!";
} else {
    echo "Error: " . $conn->error;
}
?>