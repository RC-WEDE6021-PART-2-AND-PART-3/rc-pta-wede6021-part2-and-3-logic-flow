<?php
include 'DBConn.php';

// Check if ID exists
if (!isset($_GET['id'])) {
    die("Invalid request");
}

$id = $_GET['id'];

// Validate (very important)
if (!is_numeric($id)) {
    die("Invalid user ID");
}

// Update user
$sql = "UPDATE USERS SET is_verified = 1 WHERE user_id = $id";

if ($conn->query($sql)) {
    // Redirect back to admin page
    header("Location: admin.php");
    exit();
} else {
    echo "Error: " . $conn->error;
}
?>